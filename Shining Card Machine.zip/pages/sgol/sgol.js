// pages/sgol/sgol.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showModal: false,
    DrawTime: '',
    PassTime: '',
    levelA: '',
    levelB: '',
    levelC: '',
    //score: ''
  },

  submit: function () {
    var that = this;
    this.setData({
      showModal: true,

    })

  },

  preventTouchMove: function () {

  },


  go: function () {
    this.setData({
      showModal: false
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.data.DrawTime = options.DrawTime;
    that.data.PassTime = options.PassTime;
    that.data.levelA = options.levelA;
    that.data.levelB = options.levelB;
    that.data.levelC = options.levelC;

    var score1 = that.data.levelA * 3;
    console.log(score1);
    var score0 = that.data.levelB;
    console.log(score0);
    var score2 = that.data.PassTime * 2;
    var score;
    score = parseInt(score0) + parseInt(score1) - parseInt(score2);
    console.log(score);

    this.setData({
      text1: "   你一共抽卡了" + that.data.DrawTime + "次\n其中有" + that.data.PassTime + "次触发保底\n\n\n",
      text2: "   累计一共抽中\n闪耀卡:" + that.data.levelA + "\n非凡卡:" + that.data.levelB + "\n稀有卡:" + that.data.levelC,
    });
    if (score <= 0.32 * that.data.DrawTime) {
      this.setData({
        text3: "\n   等我做了最非玩家排行榜， 一定把你加进去让你看看寄几多惨！"
      });
    }
    else if (score < 0.4 * that.data.DrawTime) {
      this.setData({
        text3: "\n   你达到了正常人的运气水平，一般情况下是抽不到闪哒！（如果有当我没说）"
      });
    }
    else if (score < 0.45 * that.data.DrawTime) {
      this.setData({
        text3: "\n   你稍微超过一点点正常人的运气水平，小欧玩家！（如果不是那当我没说）"
      });
    }
    else if (score >= 0.45 * that.data.DrawTime) {
      this.setData({
        text3: "\n   哇你刚刚运气爆棚！可以考虑去浪阁（如果没闪那当我没说）"
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})