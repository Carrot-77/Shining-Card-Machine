//index.js
//获取应用实例
const app = getApp()


Page({
  //show.js
  //获取应用实例  
  exp: function () {
    wx.showModal({
      title: '提示',
      content: '本程序不作为任何商业用途！因为没有图片资源，目前只有闪卡和非凡设计师卡能点开，如果有素材的话，我会找时间把剩下非凡卡和稀有卡都加上图片。最后感谢三区世界同萌和听风小哥哥提供的图片素材',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  tapName: function (event) {
    console.log(event)
  },
  data: {
    /*
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
    */
    DrawTime: 0,//抽卡次数
    PassTime: 0,//被动触发次数
    levelA: 0,//闪耀卡次数
    levelB: 0,//非凡卡次数
    levelC: 0,//稀有卡次数
    
    imgs: [],//图片
    hidden1: true,
    hidden2: true,
    lag: "../images/lag/0/lag00.png",
    la: "http://m.qpic.cn/psb?/V11FTC2E1kGRuP/10WV35yiyWPNZckGOJxO1KQf5g3FO5kSBaWy7YBCE9w!/b/dLYAAAAAAAAA&bo=aAF8AQAAAAADBzY!&rf=viewer_4",
    lb: "http://m.qpic.cn/psb?/V11FTC2E1kGRuP/IkBHbFdZjO2N9C.2.6QNsOY5TBvIaftheukEy4pDxLk!/b/dL4AAAAAAAAA&bo=aAF8AQAAAAADFyY!&rf=viewer_4",
    lc: "http://m.qpic.cn/psb?/V11FTC2E1kGRuP/h9vm1OhtWEEdIJq1lV0KHVsLQ2JBW01T12d6WkHq16M!/b/dLgAAAAAAAAA&bo=aAF8AQAAAAADFyY!&rf=viewer_4",
    //la: "../images/src/levelA.png",
    //lb: "../images/src/levelB.png",
    //lc: "../images/src/levelC.png",
    lA: "http://m.qpic.cn/psb?/V11FTC2E1kGRuP/xoMwnkxTqKsYhG*tiGowg873WRfBHQgZ91KGluoGAnw!/b/dLYAAAAAAAAA&bo=aAF8AQAAAAADFyY!&rf=viewer_4",
    lB: "http://m.qpic.cn/psb?/V11FTC2E1kGRuP/98AiK7Xrf3YktgREaGSq3GHmD8DqL*BXR7IVvclJOps!/b/dLYAAAAAAAAA&bo=aAF8AQAAAAADFyY!&rf=viewer_4",
    lC: "http://m.qpic.cn/psb?/V11FTC2E1kGRuP/XSVCfGFw4TII1QtBV.or81IiLAXDupomY3b8NdPqJ7Y!/b/dFMBAAAAAAAA&bo=aAF8AQAAAAADFyY!&rf=viewer_4",
    //lA: "../images/src/Alevel.png",
    //lB: "../images/src/Blevel.png",
    //lC: "../images/src/Clevel.png",
    lls01: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/ZgJf3nCZv7rNv9g0DKLpF4*EG50oCQr2RdVRytZDRxs!/m/dFQBAAAAAAAAnull&bo=UQFSAQAAAAADByE!&rf=photolist&t=5",
    lls02: "http://a3.qpic.cn/psb?/V11FTC2E27xyem/XkLOe6JQIl*fyv8xarUBsBRz1LF*EbAymvMO13mP458!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls03: "http://a2.qpic.cn/psb?/V11FTC2E27xyem/nU4kn.bPtbEliQAchErtNMxcDquixI2H5JqI7yKAatg!/m/dLkAAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    lls04: "http://a4.qpic.cn/psb?/V11FTC2E27xyem/NsrpEMLj9rigKzdEFQGlT*k.0NIN8aqOy3h.r6kOUCc!/m/dL8AAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls05: "http://a4.qpic.cn/psb?/V11FTC2E27xyem/d9ICgh95*vAr3k9v2lVlKn*aRK3Kn9PDFl8eOQePEQE!/m/dL8AAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls06: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/cTcc3T2CoGQeEvkKhiSMGax8I17W.GtsB8yZSJaIi9g!/m/dAQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls07: "http://a4.qpic.cn/psb?/V11FTC2E27xyem/AXOD0p3xyOxE7gbiPnxA8vTUFjY51a*BNySmuvVcSdk!/m/dL8AAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls08: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/QXLCSz6C8rAKDTnnpBbJsZTNpzCLjRwfxFhRBylkZMI!/m/dDQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls09: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/0ArZYX0hFUSR04EcPw49iI0RXu1lrnvjVVRLo6SVZkY!/m/dFQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls10: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/4zQfc446Ywft6K2k3Xzqv1vd9prVzxJxx07idOMz1Rg!/m/dFQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls11: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/ucf*WuRxqNQNPD0MLMxn*3DAR45j8nPESqWISxAvU*g!/m/dFQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls12: "http://a3.qpic.cn/psb?/V11FTC2E27xyem/sbVDeRPFyhOV55AuS*t7LMh6UAihnR8ZW3N8DSmhM9M!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls13: "http://a1.qpic.cn/psb?/V11FTC2E27xyem/6edvEBaKHtazLkYzP*AMkVatMncgKPpg5LCsLiYojXk!/m/dFQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lls14: "http://a3.qpic.cn/psb?/V11FTC2E27xyem/sWdm8L2aT5meIHLsZBe27Bi2gJkQ6poutPfK8eQ5UdQ!/m/dFIBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag01: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/F0q1BM2zR.TW3KnEV8g3Src.O8kmcDKi9iC8YYOIiBQ!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag02: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/3nHus.DXBqHu38CkObWARfVbuwxKWTpWqIXQT4UvKS8!/m/dFIBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag03: "http://a4.qpic.cn/psb?/V11FTC2E4ZDpx3/QmljhfvbXOll7gQDpaiTM5J04Y6sPS1cGXEgB1xCsek!/m/dL8AAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag04: "http://a1.qpic.cn/psb?/V11FTC2E4ZDpx3/x9zOpXKXuxVgZ*rvAY9O2hqB1pY7vCnmT6n2gow7aWk!/m/dDQBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag05: "http://a4.qpic.cn/psb?/V11FTC2E4ZDpx3/EwNneYRHkVS4FDbk2ROavNkRPwG8tj7rYE61XcwA0eI!/m/dL8AAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag06: "http://a1.qpic.cn/psb?/V11FTC2E4ZDpx3/GTGeKLQIKF26z4vwzmsG24vaWVFhdpgbYvp2OBHG4U4!/m/dFQBAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    lag07: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/3*6MP4Zgap8jxrXaCYc4bKmFN*aPPtgCjFY5L2Zrx6g!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag08: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/Q4u4YeShCopdahxs6V0LewehNw*62HJlxX0t.4QTvJ4!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag09: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/M2PB7CE*.BTvp1y8ffCTn9aKLE8ITz33zs1ijjbdUoA!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag10: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/1SQB2I.nMCKnSnETxxJNDLYlYBUkSfJblDc5PXIApWc!/m/dFIBAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    lag11: "http://a1.qpic.cn/psb?/V11FTC2E4ZDpx3/vFSq5qJtAAROr7IZg4lQEHupRLDeuieJeIwJcdOBO*M!/m/dLgAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    lag12: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/lD4xfnU2gMMWdC5P*nHAzkLOFRmJAlV22ixsXVdPA0g!/m/dE4BAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    lag13: "http://a3.qpic.cn/psb?/V11FTC2E4ZDpx3/sZS6iGvQFLRgrwe5LwQ1x50.bfS*myYDzCNKhLkAJ7o!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    oth1: "http://a3.qpic.cn/psb?/V11FTC2E3xViHx/p36y5d2WaWtkSwrei9XxiG*zff4n8qftI.jrPb.DZTI!/m/dD4BAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    oth2: "http://a3.qpic.cn/psb?/V11FTC2E3xViHx/XJbQoPAJ3BUYiYg2QpYF55ueX1YWOBGWyjpBbCh8TjA!/m/dFIBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    oth3: "http://a4.qpic.cn/psb?/V11FTC2E3xViHx/55OVPmfNdjJ34akgolmYwbS*uw3zAmjWzv.*iwSYinw!/m/dMMAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    oth4: "http://a2.qpic.cn/psb?/V11FTC2E3xViHx/u8qGkR4HqT8DVIMT9DdVO4LV.06OjrGyWEqpSTj7s2s!/m/dAUBAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    oth5: "http://a3.qpic.cn/psb?/V11FTC2E3xViHx/NSeX39a4sLd5SDlmZV0sAL2N5yKRdFkQNhZGRWBD3zA!/m/dLYAAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    car0: "http://a4.qpic.cn/psb?/V11FTC2E3xViHx/5Y5USRsfOa341hP8Ixt2R8BJWVGe0mW4lAHv1gegego!/m/dL8AAAAAAAAAnull&bo=UQFSAVEBUgEDCSw!&rf=photolist&t=5",
    car1: "http://a4.qpic.cn/psb?/V11FTC2E3xViHx/oWT.qVDZxt1TJMT36dzIdVCz7Zn7I*QDgC2d7ASok.s!/m/dL8AAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    car2: "http://a3.qpic.cn/psb?/V11FTC2E3xViHx/LTWoV8WsAZS*bKLzwlMATrDflC5CK6SvM9qBYV8XRu8!/m/dL4AAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    car3: "http://a3.qpic.cn/psb?/V11FTC2E3xViHx/78Z8ZWZ292NNyXmoR*z81rbSODsL0B5N9GNaN5sTEZo!/m/dLYAAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    car4: "http://a3.qpic.cn/psb?/V11FTC2E3xViHx/btnQMQ.GL2Wrg70GCtc3rV.AYcNcBu9hHS2eno4Q51E!/m/dLYAAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    car5: "http://a1.qpic.cn/psb?/V11FTC2E3xViHx/XrgMB3.iG4BHmGlHWDfX.26t2LiHHPoz2BtrGC2ipVY!/m/dLgAAAAAAAAAnull&bo=aAF8AWgBfAEDCSw!&rf=photolist&t=5",
    src0: "",
    src1: "",
    src2: "",
    src3: "",
    src4: "",
    src5: "",
    src6: "",
    src7: "",
    src8: "",
    src9: "",
    src10: "",
    src11: "",
    src0s: "",
    src1s: "",
    src2s: "",
    src3s: "",
    src4s: "",
    src5s: "",
    src6s: "",
    src7s: "",
    src8s: "",
    src9s: "",
    src10s: "",
    src11s: "",
    src12s: "",
    disable: true,
    opacity: 0,
  },
  fanmian: function (e) {
    var that = this;
    var tempexperienceid = e.currentTarget.dataset.experienceid;
    console.log(tempexperienceid)
    var key1 = "src" + tempexperienceid;
    var key2 = "src" + tempexperienceid + "s"
    var data1 = {}
    console.log(that.data[key2])
    data1[key1] = that.data[key2];
    console.log(data1)
    that.setData(data1)
  },

  anhide: function(e) {
    var that = this;
    wx.navigateTo({
      url: '../../pages/sgol/sgol?DrawTime=' + that.data.DrawTime + '&PassTime=' + that.data.PassTime + '&levelA=' + that.data.levelA + '&levelB=' + that.data.levelB + '&levelC=' + that.data.levelC,
    });
  },

  //单抽
  once: function () {
    var that = this;
    
    /*
    if (that.data.DrawTime > 200) {
      wx.navigateTo({
        url: '../../pages/sgol/sgol?DrawTime=' + that.data.DrawTime + '&PassTime=' + that.data.PassTime + '&levelA=' + that.data.levelA + '&levelB=' + that.data.levelB + '&levelC=' + that.data.levelC,
      })
    }
    */
    let draw = 1;
    let cloth1;
    cloth1 = that.DrawCard1(draw);
    console.log(this.Judge(cloth1));
    this.data.DrawTime += 1;
    var othal = [that.data.oth1, that.data.oth2, that.data.oth3, that.data.oth4, that.data.oth5];
    var llslag1 = [that.data.lls02, that.data.lls03, that.data.lls04, that.data.lls05, that.data.lls06, that.data.lls07, that.data.lls09, that.data.lls10, that.data.lls11, that.data.lls12, that.data.lls13, that.data.lls14, that.data.lag02, that.data.lag03, that.data.lag04, that.data.lag06, that.data.lag07, that.data.lag08, that.data.lag09, that.data.lag10, that.data.lag11, that.data.lag12, that.data.lag13];
    var fan = [that.data.car1, that.data.car2, that.data.car3, that.data.car4, that.data.car5];
    if (cloth1 <= 27) {
      that.setData({
        src11: that.data.lA,
        src11s: that.data.lls01,
        hidden1: true,
        hidden2: false
      })
    }
    else if (cloth1 <= 50) {
      that.setData({
        src11: that.data.lA,
        src11s: that.data.lag01,
        hidden1: true,
        hidden2: false
      })
    }
    else if (cloth1 <= 300) {
      if (cloth1 <= 257) {
        var k = parseInt((cloth1 - 51) / 9);
        that.setData({
          src11: that.data.la,
          src11s: llslag1[k],
          hidden1: true,
          hidden2: false
        })
      }
      else if (cloth1 <= 292) {
        var k = parseInt((cloth1 - 258) / 7);
        that.setData({
          src11: that.data.la,
          src11s: othal[k],
          hidden1: true,
          hidden2: false
        })
      }
      else {
        if (cloth1 <= 296) {
          that.setData({
            src11: that.data.la,
            src11s: that.data.lls08,
            hidden1: true,
            hidden2: false
          })
        }
        else {
          that.setData({
            src11: that.data.la,
            src11s: that.data.lag05,
            hidden1: true,
            hidden2: false
          })
        }
      }
    }
    else if (cloth1 <= 595) {
      var k = parseInt((cloth1 - 301) / 59);
      that.setData({
        src11: that.data.lB,
        src11s: fan[k],
        hidden1: true,
        hidden2: false
      })
    }
    else if (cloth1 <= 600) {
      that.setData({
        src11: that.data.lB,
        src11s: that.data.car0,
        hidden1: true,
        hidden2: false
      })
    }
    else if (cloth1 <= 3100) {
      that.setData({
        src11: that.data.lb,
        src11s: that.data.lb,
        hidden1: true,
        hidden2: false
      })
    }
    else if (cloth1 <= 3720) {
      that.setData({
        src11: that.data.lC,
        src11s: that.data.lC,
        hidden1: true,
        hidden2: false
      })
    }
    else {
      that.setData({
        src11: that.data.lc,
        src11s: that.data.lc,
        hidden1: true,
        hidden2: false
      })
    }

    for (let i = 0; i <= 9; i++) {
      var num = i;
      var key = "src" + num;
      var data = {}
      data[key] = "";
      that.setData(data)
    }
    if (that.data.DrawTime >= 200) {
      app.globalData.anlshow = true
    } else {
      app.globalData.anlshow = false
    }
    this.setData({
      disable: !(app.globalData.anlshow),
      opacity: !(app.globalData.anlshow) == true ? 0 : 0.8
    });
  },

  //十连
  tenth: function () {
    var that = this;
    
    /*
    if (that.data.DrawTime > 200) {
      wx.navigateTo({
        url: '../../pages/sgol/sgol?DrawTime=' + that.data.DrawTime + '&PassTime=' + that.data.PassTime + '&levelA=' + that.data.levelA + '&levelB=' + that.data.levelB + '&levelC=' + that.data.levelC,
      })
    }
    */

    for (let i = 0; i <= 9; i++) {
      var num = i;
      var key = "src" + num;
      var data = {}
      data[key] = "";
      that.setData(data)
    }

    let BlackTime;
    let draw = 1;
    BlackTime = 0;
    var cloth = [];
    for (let i = 0; i < 9; i++) {
      cloth[i] = that.DrawCard1();
      console.log(this.Judge(cloth[i]));
      if (cloth[i] > 3100) BlackTime++;
    }

    //如果触发了十连非凡被动
    if (BlackTime == 9) {
      this.data.PassTime++;
      cloth[9] = that.DrawCard2(draw);
      console.log(this.Judge(cloth[9]));
    }
    //没有触发十连非凡被动
    else {
      cloth[9] = that.DrawCard1(draw);
      console.log(this.Judge(cloth[9]));
    }
    this.data.DrawTime += 10;
    var i = 0;
    setInterval(function () {
      if (i <= 9) {
        var num = i;
        var key = "src" + num;
        var key1 = "src" + num + "s";
        var data = {}
        var data1 = {}
        var othal = [that.data.oth1, that.data.oth2, that.data.oth3, that.data.oth4, that.data.oth5];
        var llslag1 = [that.data.lls02, that.data.lls03, that.data.lls04, that.data.lls05, that.data.lls06, that.data.lls07, that.data.lls09, that.data.lls10, that.data.lls11, that.data.lls12, that.data.lls13, that.data.lls14, that.data.lag02, that.data.lag03, that.data.lag04, that.data.lag06, that.data.lag07, that.data.lag08, that.data.lag09, that.data.lag10, that.data.lag11, that.data.lag12, that.data.lag13];
        var fan = [that.data.car1, that.data.car2, that.data.car3, that.data.car4, that.data.car5];
        if (cloth[i] <= 27) {
          data[key] = that.data.lA;
          data1[key1] = that.data.lls01;
          that.setData(data)
          that.setData(data1)
          console.log(that.data.lls01)
        }
        else if (cloth[i] <= 50) {
          data[key] = that.data.lA;
          data1[key1] = that.data.lag01;
          that.setData(data)
          that.setData(data1)
          console.log(that.data.lag)
        }
        else if (cloth[i] <= 300) {
          if (cloth[i] <= 257) {
            var k = parseInt((cloth[i] - 51) / 9);
            data[key] = that.data.la;
            data1[key1] = llslag1[k];
            that.setData(data)
            that.setData(data1)
            console.log(llslag1[k])
          }
          else if (cloth[i] <= 292) {
            var k = parseInt((cloth[i] - 258) / 7);
            data[key] = that.data.la;
            data1[key1] = othal[k];
            that.setData(data)
            that.setData(data1)
            console.log(othal[k])
          }
          else {
            if (cloth[i] <= 296) {
              data[key] = that.data.la;
              data1[key1] = that.data.lls08;
              that.setData(data)
              that.setData(data1)
              console.log(that.data.lls08)
            }
            else {
              data[key] = that.data.la;
              data1[key1] = that.data.lag05;
              that.setData(data)
              that.setData(data1)
              console.log(that.data.lag05)
            }
          }
        }

        else if (cloth[i] <= 595) {
          var k = parseInt((cloth[i] - 301) / 59);
          data[key] = that.data.lB;
          data1[key1] = fan[k];
          that.setData(data)
          that.setData(data1)
          console.log(othal[k])
        }
        else if (cloth[i] <= 600) {
          data[key] = that.data.lB;
          data[key1] = that.data.car0;
          that.setData(data)
          that.setData(data1)
          console.log(that.data.car0)
        }

        else if (cloth[i] <= 3100) {
          data[key] = that.data.lb;
          data[key1] = that.data.lb;
          that.setData(data)
        }
        else if (cloth[i] <= 3720) {
          data[key] = that.data.lC;
          data[key1] = that.data.lC;
          that.setData(data)
        }
        else {
          data[key] = that.data.lc;
          data[key1] = that.data.lc;
          that.setData(data)
        }

        i++;
      }

    }, 0)

    if (that.data.DrawTime >= 200) {
      app.globalData.anlshow = true
    } else {
      app.globalData.anlshow = false
    }

    that.setData({
      hidden1: false,
      hidden2: true,
    });
    
    this.setData({
      disable: !(app.globalData.anlshow),
      opacity: !(app.globalData.anlshow) == true ? 0 : 0.8
    });
    

  },

  selectcard: function () {
    console.log(Math.floor(Math.random() * 10000))
  },


  //正常概率函数
  DrawCard1: function (state) {
    var that = this;
    let onecard = Math.floor(Math.random() * 10000);
    if (onecard <= 300) {
      this.data.levelA++;
    }
    else if (onecard <= 3100) {
      this.data.levelB++;
    }
    else {
      this.data.levelC++;
    }
    return onecard;
  },

  //必出非凡函数
  DrawCard2: function (state) {
    var that = this;
    let onecard = Math.floor(Math.random() * 10000);
    while (onecard > 3100) {
      onecard = Math.floor(Math.random() * 10000);
    }
    if (onecard <= 300) this.data.levelA++;
    else this.data.levelB++;
    return onecard;
  },

  //抽卡输出
  Judge: function (num) {
    if (num <= 27)
      return "闪耀设计师之影：莉莉丝";
    else if (num <= 50)
      return "闪耀设计师之影：洛昂";
    else if (num <= 158)
      return "闪耀服饰：莉莉丝部件";
    else if (num <= 257)
      return "闪耀服饰：洛昂部件";
    else if (num <= 292)
      return "闪耀服饰：单件";
    else if (num <= 296)
      return "闪耀服饰：欲望之音";
    else if (num <= 300)
      return "闪耀服饰：露凝晨雾";
    else if (num <= 3100)
      return "非凡";
    else return "稀有";
  },

  btn_default: function () {
    var that = this;

  },



  onLoad: function () {
    /*
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {{}
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
      
    }
    */

  },
  /*
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
    
  }
  */
})
